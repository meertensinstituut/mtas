Get CHAT transcripts Paris Corpus from http://childes.talkbank.org/access/French/Paris.html
Convert CHAT transcripts to XML using Chatter from http://talkbank.org/software/chatter.html

